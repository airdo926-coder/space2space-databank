function openOrder(pkg){
    document.getElementById('package').value = pkg;
    document.getElementById('orderModal').style.display = 'block';
}

function submitOrder(){
    let phone = document.getElementById('phone').value;
    let pkg = document.getElementById('package').value;

    if(phone === ''){
        alert('Please enter phone number');
        return;
    }

    let message = `New Data Order - Space 2 Space Databank
Package: ${pkg}
Phone: ${phone}
Network: MTN
Payment: Wallet`;

    let mailLink = `mailto:airdo926@gmail.com,clementanane221@gmail.com,clementairdo@icloud.com?subject=New Data Order&body=${encodeURIComponent(message)}`;
    window.location.href = mailLink;

    document.getElementById('successMsg').innerHTML =
        '✅ Order placed successfully. Please complete payment.';

    setTimeout(()=>{
        document.getElementById('orderModal').style.display='none';
        document.getElementById('phone').value='';
    },2500);
}
